function geolocation(){
    if(navigator.geolocation)
    {
     navigator.geolocation.getCurrentPosition(onSuccess,onError);
    }else{
    console.log("Not supported");
    }
    }
    
    function onSuccess(position){
    const {latitude,longitude}=position.coords;
    const url =`https://www.latlong.net/c/?lat=${latitude}&long=${longitude}`;
    document.querySelector('a').setAttribute('href',url);
    document.querySelector('div').style.display='block';    
    
    console.log(position);
    }
    
    function onError(error){
        console.log(error);
    }
    


    function accept(email)
    {

     
alert("request accepted work");
        var email = email;
      var  output = localStorage.getItem('users');
        output= JSON.parse(output);
       var datalist =[];
       output.find(item =>{
           if(item.email === email){
            item.flag = 0;
            datalist.push(item);
        }else{
            datalist.push(item); 
           }
       });

    localStorage.setItem('users',JSON.stringify(datalist));
    var arr =   localStorage.getItem('users');

   
    window.location.reload();
}

    